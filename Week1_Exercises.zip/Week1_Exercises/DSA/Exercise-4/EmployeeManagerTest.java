public class EmployeeManagerTest {
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager(5);

        Employee emp1 = new Employee("1", "Alice", "Manager", 75000);
        Employee emp2 = new Employee("2", "Bob", "Developer", 60000);

        manager.addEmployee(emp1);
        manager.addEmployee(emp2);

        manager.traverseEmployees();

        Employee found = manager.searchEmployee("1");
        System.out.println("Found: " + found);

        manager.deleteEmployee("2");
        manager.traverseEmployees();
    }
}
