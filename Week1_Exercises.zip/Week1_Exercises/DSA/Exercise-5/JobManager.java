public class JobManager {
    
    private class Node {
        Job job;
        Node next;

        Node(Job job) {
            this.job = job;
        }
    }

    private Node head;

    public void addJob(Job job) {
        Node newNode = new Node(job);
        newNode.next = head;
        head = newNode;
    }

    public Job searchJob(int jobId) {
        Node current = head;
        while (current != null) {
            if (current.job.getJobId() == jobId) {
                return current.job;
            }
            current = current.next;
        }
        return null;
    }

    public boolean deleteJob(int jobId) {
        if (head == null) return false;

        if (head.job.getJobId() == jobId) {
            head = head.next;
            return true;
        }

        Node current = head;
        while (current.next != null && current.next.job.getJobId() != jobId) {
            current = current.next;
        }

        if (current.next != null) {
            current.next = current.next.next;
            return true;
        }
        return false;
    }

    public void traverseJobs() {
        Node current = head;
        while (current != null) {
            System.out.println(current.job);
            current = current.next;
        }
    }

    public static void main(String[] args) {
        JobManager jms = new JobManager();
        jms.addJob(new Job(1, "Design", "Incomplete"));
        jms.addJob(new Job(2, "Implementation", "Incomplete"));
        jms.addJob(new Job(3, "Testing", "Incomplete"));

        System.out.println("Traversing jobs:");
        jms.traverseJobs();

        System.out.println("\nSearching for job with ID 2:");
        Job j = jms.searchJob(2);
        System.out.println(j != null ? j : "Job not found.");

        System.out.println("\nDeleting job with ID 2:");
        boolean deleted = jms.deleteJob(2);
        System.out.println(deleted ? "Job deleted." : "Job not found.");

        System.out.println("\nTraversing jobs after deletion:");
        jms.traverseJobs();
    }
}