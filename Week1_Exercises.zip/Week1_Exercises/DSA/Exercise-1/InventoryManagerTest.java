public class InventoryManagerTest {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();

        Product product1 = new Product("1", "Product 1", 10, 100.0);
        Product product2 = new Product("2", "Product 2", 20, 200.0);

        manager.addProduct(product1);
        manager.addProduct(product2);

        manager.displayInventory();

        manager.updateProduct("1", 15, 110.0);
        manager.deleteProduct("2");

        manager.displayInventory();
    }
}
