


import java.util.Arrays;

public class SearchTest {
    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Shirt", "Clothing"),
            new Product("3", "Book", "Books"),
            new Product("4", "Phone", "Electronics"),
            new Product("5", "Shoes", "Footwear")
        };

        // Sort products array for binary search
        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareToIgnoreCase(p2.getProductName()));

        // Linear Search
        Product result = SearchAlgorithms.linearSearch(products, "Phone");
        if (result != null) {
            System.out.println("Linear Search: " + result);
        } else {
            System.out.println("Product not found in Linear Search.");
        }

        // Binary Search
        result = SearchAlgorithms.binarySearch(products, "Phone");
        if (result != null) {
            System.out.println("Binary Search: " + result);
        } else {
            System.out.println("Product not found in Binary Search.");
        }
    }
}

