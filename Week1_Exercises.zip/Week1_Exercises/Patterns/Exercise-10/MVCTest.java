public class MVCTest {
    public static void main(String[] args) {
        // Create a Student model object
        Student student = new Student("John Doe", "12345", "A");

        // Create a StudentView object
        StudentView view = new StudentView();

        // Create a StudentController object
        StudentController controller = new StudentController(student, view);

        controller.updateView();
        controller.setStudentName("Jane Doe");
        controller.setStudentGrade("B");

        // Display updated student details
        controller.updateView();
    }
}
