public class FactoryMethodTest {
    public static void main(String[] args) {

        // Create factories for different document types
        DocumentFactory wordFactory = new WordDocumentFactory();
        DocumentFactory pdfFactory = new PdfDocumentFactory();
        DocumentFactory excelFactory = new ExcelDocumentFactory();

        // Create and open documents using the factories
        Document wordDoc = wordFactory.createDocument();
        wordDoc.open();

        Document pdfDoc = pdfFactory.createDocument();
        pdfDoc.open();

        Document excelDoc = excelFactory.createDocument();
        excelDoc.open();
    }
}
