public class AdapterTest {
    public static void main(String[] args) {
        //payPal object
        PayPal payPal = new PayPal();

        //PayPalAdapter object
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPal);

        // Process a payment using the adapter
        payPalAdapter.processPayment(100.0);
    }
}
