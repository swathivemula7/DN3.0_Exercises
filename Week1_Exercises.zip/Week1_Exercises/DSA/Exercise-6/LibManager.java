public class LibManager {
	
	    private Book[] books;

	    public LibManager(Book[] books) {
	        this.books = books;
	    }

	    public Book linearSearch(String title) {
	        for (Book book : books) {
	            if (book.getTitle().equalsIgnoreCase(title)) {
	                return book;
	            }
	        }
	        return null;
	    }

	    public Book binarySearch(String title) {
	        int left = 0, right = books.length - 1;
	        while (left <= right) {
	            int mid = left + (right - left) / 2;
	            int cmp = books[mid].getTitle().compareToIgnoreCase(title);
	            if (cmp == 0) return books[mid];
	            if (cmp < 0) left = mid + 1;
	            else right = mid - 1;
	        }
	        return null;
	    }

	    public static void main(String[] args) {
	        Book[] books = {
	            new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"),
	            new Book(2, "1984", "George Orwell"),
	            new Book(3, "To Kill a Mockingbird", "Harper Lee"),
	            new Book(4, "Moby-Dick", "Herman Melville")
	        };

	        LibManager lms = new LibManager(books);

	        System.out.println("Searching for '1984' using Linear Search:");
	        Book foundBook = lms.linearSearch("1984");
	        System.out.println(foundBook != null ? foundBook : "Book not found.");

	        System.out.println("\nSearching for 'Moby-Dick' using Binary Search:");
	        foundBook = lms.binarySearch("Moby-Dick");
	        System.out.println(foundBook != null ? foundBook : "Book not found.");
	    }
	}



