public class Job {
    private int jobId;
    private String jobName;
    private String status;

    public Job(int jobId, String jobName, String status) {
        this.jobId = jobId;
        this.jobName = jobName;
        this.status = status;
    }

    // Getters and Setters
    public int getJobId() { return jobId; }
    public void setJobId(int jobId) { this.jobId = jobId; }

    public String getJobName() { return jobName; }
    public void setJobName(String jobName) { this.jobName = jobName; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "Job{" +
                "jobId=" + jobId +
                ", jobName='" + jobName + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}