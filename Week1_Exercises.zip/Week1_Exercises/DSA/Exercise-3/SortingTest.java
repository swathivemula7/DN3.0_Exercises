import java.util.Arrays;

public class SortingTest {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Alice", 250.0),
            new Order("2", "Bob", 150.0),
            new Order("3", "Charlie", 350.0),
            new Order("4", "David", 200.0)
        };

        // Bubble Sort
        System.out.println("Bubble Sort:");
        SortingAlgorithms.bubbleSort(orders);
        System.out.println(Arrays.toString(orders));

        // Quick Sort
        orders = new Order[]{
            new Order("1", "Alice", 250.0),
            new Order("2", "Bob", 150.0),
            new Order("3", "Charlie", 350.0),
            new Order("4", "David", 200.0)
        };

        System.out.println("Quick Sort:");
        SortingAlgorithms.quickSort(orders, 0, orders.length - 1);
        System.out.println(Arrays.toString(orders));
    }
}
